import Metricas from '../components/home-page/Metricas'
const Metrica = () => {
    return (
      <>
      
      <Metricas />
      </>
    )
  }
  
  export default Metrica