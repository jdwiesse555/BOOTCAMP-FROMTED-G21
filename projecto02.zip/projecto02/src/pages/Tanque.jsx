import Tanques from '../components/home-page/Tanques'

const Tanque = () => {
    return (
     <>
      <Tanques />
      </>
    )
  }
  
  export default Tanque