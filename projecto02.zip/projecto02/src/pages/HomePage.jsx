import  LayoutBase  from '../layouts/LayoutBase'

export const HomePage = () => {
    return (
      <>
      {<LayoutBase/>}

      <div className="flex flex-col   ">
        
        <img alt="centered image" src="https://image.freepik.com/foto-gratis/imagen-tanques-petroleo-refineria-dia-soleado_232070-5383.jpg" />
       
      </div>
      </>
    )
  }