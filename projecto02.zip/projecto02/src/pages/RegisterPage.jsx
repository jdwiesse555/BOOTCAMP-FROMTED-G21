import  LayoutBase  from '../layouts/LayoutBase'

export const RegisterPage = () => {
    return (
    <>
      {<LayoutBase/>}
      <h1>register 222</h1>
      </>
    )
  }